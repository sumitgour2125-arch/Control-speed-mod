# Amethyst Smart Miner

Client-side smooth POV aim assist for amethyst blocks in Minecraft Java 1.21.4 / Forge 54.1.6.
The player remains responsible for mining input.

## Features
- Toggle aim assist with `G` (default).
- Adjust target reach with `[` and `]` (default).
- Adjust the delay after a target block breaks with `=` (faster), `-` (slower), and `\\` (reset).
- Switching delay defaults to **0 ms**. The client selects the next target on the first client tick after it observes that the previous target is no longer amethyst (normally within one 20 TPS tick, about 50 ms).
- Adjustable delay range: 0–500 ms in 25 ms steps.

All keys can be changed in Minecraft: Options → Controls → Key Binds → Amethyst Smart Miner.

## Build
Use Java 21 and ForgeGradle with Gradle 8.8. Run `gradle build` from this project directory. The produced mod JAR is in `build/libs/`.
