package com.example.amethystsmartminer;

import net.minecraftforge.fml.common.Mod;

@Mod(AmethystSmartMiner.MOD_ID)
public final class AmethystSmartMiner {
    public static final String MOD_ID = "amethystsmartminer";

    public AmethystSmartMiner() {
        // Client behavior is registered by the client-only event subscribers.
    }
}
